Para executar o projecto, 
1.)poder� abrir os execut�veis individuais:
	Correr primeiro o executavel do servidor que se encontra na pasta Server/bin/Debug/server.exe
	Abrir o numero de clientes que pretender, cujo execut�vel se encontra na pasta Client/bin/Debug/Client.exe
2.)Abrir a solu��o de visual studio 2013 fornecida no zip.

A intera��o com a interface gr�fica dos clientes dever� ser feita conforme explicada no relat�rio enviado em anexo.

Projecto realizado por:
Daniel Pereira - ei11132
Pedro Silva - ei11061